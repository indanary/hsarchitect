import{j as t,L as r}from"./LayoutWrapper.CBTHnm6B.js";import"./index.B28oNxVQ.js";function a(){return t.jsx(r,{showSearch:!0})}export{a as default};
